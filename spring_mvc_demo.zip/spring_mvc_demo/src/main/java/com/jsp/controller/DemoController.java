package com.jsp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DemoController {

	@RequestMapping("/hi")
	public String sayHi() {
		return "index.jsp";
	}
	
	@RequestMapping("/info")
	public String info(Model model) {
		model.addAttribute("myname","priya");
		return "display.jsp";
	}
	
	@RequestMapping("/display")
	public ModelAndView display() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("myname","Darshan");
		mv.setViewName("show.jsp");
		return mv;
	}
}
