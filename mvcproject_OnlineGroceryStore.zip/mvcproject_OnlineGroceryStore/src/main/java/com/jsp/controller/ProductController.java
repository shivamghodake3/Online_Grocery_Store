package com.jsp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.Dao.ProductDao;
import com.jsp.Dto.Product;

@Controller
public class ProductController {

	@Autowired
	ProductDao dao;
	
	@RequestMapping("/products")
	public ModelAndView saveProducts() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("product",new Product());
		mv.setViewName("createp.jsp");
		return mv;
	}
	
	@RequestMapping("/savep")
	@ResponseBody //use only if we are returning data
	public String addProduct(@ModelAttribute Product product) {
		dao.addProduct(product);
		return "PRODUCTS DETAILS ADDED SUCCESSFULLY...";
	}
	
	
	@RequestMapping("/search")
	public ModelAndView searchProduct() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("product",new Product());
		mv.setViewName("getp.jsp");
		return mv;
	}
	
	 @RequestMapping("/view")
	    public ModelAndView findProductByName(@ModelAttribute Product product) {
	        String name = product.getName();
	        Product prod = dao.findProductByName(name);
	        ModelAndView mv = new ModelAndView();
	        if (prod != null) {
	            mv.addObject("product", prod);
	            mv.setViewName("displayp.jsp"); 
	        } else {
	        	
	        	 mv.addObject("message", "Product not available.");
		         mv.setViewName("message.jsp");
	        }
	        return mv;
	    }
	 
	 
	 @RequestMapping("/display")
	 public ModelAndView displayAllProducts() {
		 
		 List<Product> list=dao.getAllProducts();
		 ModelAndView mv=new ModelAndView();
		 mv.addObject("productList",list);
		 mv.setViewName("displayAll.jsp");
		 return mv;
		 
	 }
	 
	 @RequestMapping("/purchase")
	 public ModelAndView purchaseProduct(Product product) {
		 ModelAndView mv=new ModelAndView();
		 mv.addObject("product",new Product());
		 mv.setViewName("purchase.jsp");
		 return mv;
	 }
	 
	 @RequestMapping("/bill")
	 @ResponseBody
	 public ModelAndView displayBill(@ModelAttribute Product product) {
	     String name = product.getName();
	     Product prod = dao.findProductByName(name); 
	     ModelAndView mv = new ModelAndView();
	     
	     if (prod != null) {
	         int quantity = product.getQuantity();
	         int totalPrice = prod.getPrice() * quantity; 
	         prod.setQuantity(prod.getQuantity() - quantity); 
	         
	         dao.updateProduct(prod); 
	         
	         mv.addObject("product", new Product());
	         mv.addObject("name", name);
	         mv.addObject("price", prod.getPrice());
	         mv.addObject("quantity", quantity);
	         mv.addObject("totalPrice", totalPrice);
	         mv.setViewName("bill.jsp");
	     }
	     
		 else {
			 mv.addObject("message", "PRODUCT NOT AVAILABLE.");
	         mv.setViewName("message.jsp");
		 }
		 return mv;
		 
	 }
} 

	 

