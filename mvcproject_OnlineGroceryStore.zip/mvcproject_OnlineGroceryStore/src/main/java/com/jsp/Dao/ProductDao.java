package com.jsp.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Dto.Product;


@Repository
public class ProductDao {

	@Autowired
	EntityManager manager;
	
	@Autowired
	EntityTransaction transaction;
	
	//to add products objects in db
	public void addProduct(Product product) {
		transaction.begin();
		manager.persist(product);
		transaction.commit();
	}
	
	//to find an product by name
	public Product findProductByName(String name) {
        Query query = manager.createQuery("SELECT p FROM Product p WHERE p.name = :name", Product.class);
        query.setParameter("name", name);
        try {
            return (Product)query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }
	
	
	// Get all products
	public List<Product> getAllProducts() {
		Query query = manager.createQuery("SELECT p FROM Product p", Product.class);
		return query.getResultList();
	}
	
	//To update product stock
	public void updateProduct(Product product) {
		transaction.begin();
		manager.merge(product);
		transaction.commit();
		
	}
	

    
	
}


